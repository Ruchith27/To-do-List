# Todolist-react-node
To do list app using Reactjs(NodeJs) and Tailwind css

# Screen Shot

![Screenshot 2023-09-13 154739](https://github.com/darsh5921/Todolist-react-node/assets/104684690/fa03031e-fdd6-433f-a194-8153cb39b66c)

